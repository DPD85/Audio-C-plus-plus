#pragma once

#define unused(x) (void)(x)
