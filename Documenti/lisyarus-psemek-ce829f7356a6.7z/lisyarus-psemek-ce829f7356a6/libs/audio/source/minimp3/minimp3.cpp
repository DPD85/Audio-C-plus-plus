#define MINIMP3_IMPLEMENTATION
#include <psemek/audio/minimp3/options.h>
#include <psemek/audio/minimp3/minimp3.h>
