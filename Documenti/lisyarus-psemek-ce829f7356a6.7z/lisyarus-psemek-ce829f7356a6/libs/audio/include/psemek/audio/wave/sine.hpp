#pragma once

#include <psemek/audio/stream.hpp>

namespace psemek::audio
{

	stream_ptr sine_wave(float frequency);

}
