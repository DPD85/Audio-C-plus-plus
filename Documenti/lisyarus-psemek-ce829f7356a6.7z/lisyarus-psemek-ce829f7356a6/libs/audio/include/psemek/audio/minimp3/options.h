#pragma once

#define MINIMP3_NO_SIMD
#define MINIMP3_FLOAT_OUTPUT
