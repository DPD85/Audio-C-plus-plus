#pragma once

#include <psemek/audio/stream.hpp>

namespace psemek::audio
{

	stream_ptr karplus_strong(float frequency);

}
