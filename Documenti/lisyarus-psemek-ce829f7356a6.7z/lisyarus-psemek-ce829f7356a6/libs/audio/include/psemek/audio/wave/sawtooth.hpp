#pragma once

#include <psemek/audio/stream.hpp>

namespace psemek::audio
{

	stream_ptr sawtooth_wave(float frequency);

}
