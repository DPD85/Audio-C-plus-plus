#pragma once

#include <psemek/audio/stream.hpp>

namespace psemek::audio
{

	stream_ptr triangle_wave(float frequency);

}
