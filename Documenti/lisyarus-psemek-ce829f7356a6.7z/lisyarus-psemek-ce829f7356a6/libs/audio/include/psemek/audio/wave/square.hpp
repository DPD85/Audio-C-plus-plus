#pragma once

#include <psemek/audio/stream.hpp>

namespace psemek::audio
{

	stream_ptr square_wave(float frequency);

}
