#pragma once

#include <string>
#include <vector>

namespace psemek::journal
{

	struct event_metadata
	{
		std::string source_file;
		int source_line;
		std::string name;
		std::vector<std::string> columns;
	};

	struct event_data
	{
		std::string time;
		std::vector<std::string> values;
	};

	struct event
	{
		event_metadata metadata;
		event_data data;
	};

	std::string current_time();

}
