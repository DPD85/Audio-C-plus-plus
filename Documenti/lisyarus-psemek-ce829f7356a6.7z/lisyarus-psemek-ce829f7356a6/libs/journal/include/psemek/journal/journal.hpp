#pragma once

#include <psemek/journal/event.hpp>
#include <psemek/util/pimpl.hpp>

#include <filesystem>

namespace psemek::journal
{

	struct journal
	{
		journal(std::filesystem::path const & path);
		~journal();

		bool enabled() const;
		void set_enabled(bool enabled);

		void log_event(event const & event);

		std::vector<std::pair<event_metadata const *, event_data>> select(std::string const & query);

	private:
		psemek_declare_pimpl
	};

}
