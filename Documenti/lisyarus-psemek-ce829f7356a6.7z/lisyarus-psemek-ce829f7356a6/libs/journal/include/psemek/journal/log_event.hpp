#pragma once

#include <psemek/journal/journal.hpp>

#include <boost/preprocessor/seq/for_each.hpp>

#include <format>

#define psemek_journal_log_event_extract_key(key, value) key
#define psemek_journal_log_event_extract_value(key, value) std::format("\"{}\"", value)

#define psemek_journal_log_event_single_attribute_key(r, data, elem) psemek_journal_log_event_extract_key elem,
#define psemek_journal_log_event_single_attribute_value(r, data, elem) psemek_journal_log_event_extract_value elem,

#define psemek_journal_log_event(JOURNAL, NAME, ATTRIBUTES) \
	if ((JOURNAL).enabled()) \
		(JOURNAL).log_event({{ \
			.source_file = __FILE__, \
			.source_line = __LINE__, \
			.name = NAME, \
			.columns = { BOOST_PP_SEQ_FOR_EACH(psemek_journal_log_event_single_attribute_key, _, ATTRIBUTES) }, \
		}, { \
			.time = ::psemek::journal::current_time(), \
			.values = { BOOST_PP_SEQ_FOR_EACH(psemek_journal_log_event_single_attribute_value, _, ATTRIBUTES) }, \
		}})
