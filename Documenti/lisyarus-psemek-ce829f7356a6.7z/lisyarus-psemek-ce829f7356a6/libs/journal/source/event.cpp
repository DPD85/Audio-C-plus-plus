#include <psemek/journal/event.hpp>

#include <chrono>
#include <format>

namespace psemek::journal
{

	std::string current_time()
	{
		const auto now = std::chrono::high_resolution_clock::now();
		return std::format("{:%FT%TZ}", now);
	}

}
