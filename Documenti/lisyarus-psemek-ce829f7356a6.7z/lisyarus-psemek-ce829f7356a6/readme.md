Psemek - a game & visualization engine.

Licensed under the terms of the [NON-AI NON-NFT MIT license](LICENSE.txt).
